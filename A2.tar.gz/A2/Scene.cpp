/*
 * Scene.cpp
 *
 *  Created on: Sep 10, 2018
 *  Author: John Hall
 */

#include "Scene.h"

#include <iostream>

#include "RenderingEngine.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//**Must include glad and GLFW in this order or it breaks**
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "texture.h"


Scene::Scene(RenderingEngine* renderer) : renderer(renderer) {
	rads = 0.0f;
	MyTexture texture;
	textureName = "image1-mandrill.png";
	bool flag = InitializeTexture(&texture, textureName, GL_TEXTURE_RECTANGLE);
	if (!flag) {
		std::cout << "Failed to initialize texture" << std::endl;
	}
	//Load texture uniform
	//Shaders need to be active to load uniforms
	glUseProgram(renderer->shaderProgram);
	//Set which texture unit the texture is bound to
	glActiveTexture(GL_TEXTURE0);
	//Bind the texture to GL_TEXTURE0
	glBindTexture(GL_TEXTURE_RECTANGLE, texture.textureID);
	//Get identifier for uniform
	GLuint uniformLocation = glGetUniformLocation(renderer->shaderProgram, "imageTexture");
	//Load texture unit number into uniform
	glUniform1i(uniformLocation, 0);

	

	if(renderer->CheckGLErrors()) {
		std::cout << "Texture creation failed" << std::endl;
	}

		// three vertex positions and assocated colours of a triangle
	rectangle.verts.push_back(glm::vec3( -1.0f, -1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( 1.0f,  -1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( 1.0f, 1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( -1.0f, -1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( 1.0f, 1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( -1.0f, 1.0f, 1.0f));

	/*rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));*/



	rectangle.drawMode = GL_TRIANGLES;

	rectangle.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle.uvs.push_back(glm::vec2( float(texture.width), 0.f));
	rectangle.uvs.push_back(glm::vec2( float(texture.width), float(texture.height)));
	rectangle.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle.uvs.push_back(glm::vec2( float(texture.width), float(texture.height)));
	rectangle.uvs.push_back(glm::vec2(0.0f, float(texture.height)));

	//Construct vao and vbos for the triangle
	RenderingEngine::assignBuffers(rectangle);

	//Send the triangle data to the GPU
	//Must be done every time the triangle is modified in any way, ex. verts, colors, normals, uvs, etc.
	RenderingEngine::setBufferData(rectangle);

	//Add the triangle to the scene objects
	objects.push_back(rectangle);


}

Scene::~Scene() {

}

void Scene::displayScene() {
	renderer->RenderScene(objects);
}

void Scene::changeColorEffect(int color) {
	glUseProgram(renderer->shaderProgram);
	colorUniform = glGetUniformLocation(renderer->shaderProgram, "colorEffect");
	glUniform1i(colorUniform, color);
}

void Scene::changeSobelEffect(int sobel) {
	glUseProgram(renderer->shaderProgram);
	sobelUniform = glGetUniformLocation(renderer->shaderProgram, "sobel");
	glUniform1i(sobelUniform, sobel);
}

void Scene::changeGaussianEffect(int gaussian) {
	glUseProgram(renderer->shaderProgram);
	gaussianUniform = glGetUniformLocation(renderer->shaderProgram, "gaussian");
	glUniform1i(gaussianUniform, gaussian);
}

void Scene::changeImage(const char* fileName) {
	objects.clear();
	rectangle.verts.clear();
	rectangle.uvs.clear();
	setTextureName(fileName);
	drawImage(fileName);
}

void Scene::blendImages(const char* backgroundImageName){
	objects.clear();
	rectangle.verts.clear();
	rectangle.uvs.clear();
	
	glEnable(GL_BLEND);
	drawImage(textureName);
	drawBackground(backgroundImageName);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	

	
	
}

void Scene::drawImage(const char* name) {
	MyTexture texture;
	
	InitializeTexture(&texture, name, GL_TEXTURE_RECTANGLE);
	glUseProgram(renderer->shaderProgram);
	
	//Set which texture unit the texture is bound to
	glActiveTexture(GL_TEXTURE0);
	//Bind the texture to GL_TEXTURE0
	glBindTexture(GL_TEXTURE_RECTANGLE, texture.textureID);
	//Get identifier for uniform
	GLuint uniformLocation = glGetUniformLocation(renderer->shaderProgram, "imageTexture");
	//Load texture unit number into uniform
	glUniform1i(uniformLocation, 0);
	if(renderer->CheckGLErrors()) {
		std::cout << "Texture creation failed" << std::endl;
	}

	

	float tHeight = texture.height;
	float tWidth = texture.width;
	float nHeight = 0.0f;
	float nWidth = 0.0f;

	if (tHeight >= tWidth) {
		nHeight = 1.0f;
		nWidth = tWidth / (tHeight);
	} else {
		nWidth = 1.0f;
		nHeight = tHeight / (tWidth);
	}
	// three vertex positions and assocated colours of a triangle
	rectangle.verts.push_back(glm::vec3( -(nWidth), -(nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( (nWidth),  -(nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( (nWidth), (nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( -(nWidth), -(nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( (nWidth), (nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( -(nWidth), (nHeight), 1.0f));

	/*rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));*/



	rectangle.drawMode = GL_TRIANGLES;

	rectangle.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle.uvs.push_back(glm::vec2( tWidth, 0.f));
	rectangle.uvs.push_back(glm::vec2( tWidth, tHeight));
	rectangle.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle.uvs.push_back(glm::vec2( tWidth, tHeight));
	rectangle.uvs.push_back(glm::vec2(0.0f, tHeight));

	//Construct vao and vbos for the triangle
	RenderingEngine::assignBuffers(rectangle);

	//Send the triangle data to the GPU
	//Must be done every time the triangle is modified in any way, ex. verts, colors, normals, uvs, etc.
	RenderingEngine::setBufferData(rectangle);

	//Add the triangle to the scene objects
	objects.push_back(rectangle);
}

void Scene::drawBackground(const char* backgroundImageName) {

	
	MyTexture texture2;
	
	InitializeTexture(&texture2, backgroundImageName, GL_TEXTURE_RECTANGLE);
	glUseProgram(renderer->shaderProgram);
	
	//Set which texture unit the texture is bound to
	glActiveTexture(GL_TEXTURE0);
	//Bind the texture to GL_TEXTURE0
	glBindTexture(GL_TEXTURE_RECTANGLE, texture2.textureID);
	//Get identifier for uniform
	GLuint uniformLocation2 = glGetUniformLocation(renderer->shaderProgram, "imageTexture2");
	//Load texture unit number into uniform
	glUniform1i(uniformLocation2, 0);
	
	
	
	

	if(renderer->CheckGLErrors()) {
		std::cout << "Texture creation failed" << std::endl;
	}
    
	blendUniform = glGetUniformLocation(renderer->shaderProgram, "blendingFlag");
	glUniform1i(blendUniform, true);
	

	float tHeight2 = texture2.height;
	float tWidth2 = texture2.width;
	float nHeight2 = 0.0f;
	float nWidth2 = 0.0f;

	if (tHeight2 >= tWidth2) {
		nHeight2 = 1.0f;
		nWidth2 = tWidth2 / (tHeight2);
	} else {
		nWidth2 = 1.0f;
		nHeight2 = tHeight2 / (tWidth2);
	}
	// three vertex positions and assocated colours of a triangle
	rectangle2.verts.push_back(glm::vec3( -(nWidth2), -(nHeight2), 1.0f));
	rectangle2.verts.push_back(glm::vec3( (nWidth2),  -(nHeight2), 1.0f));
	rectangle2.verts.push_back(glm::vec3( (nWidth2), (nHeight2), 1.0f));
	rectangle2.verts.push_back(glm::vec3( -(nWidth2), -(nHeight2), 1.0f));
	rectangle2.verts.push_back(glm::vec3( (nWidth2), (nHeight2), 1.0f));
	rectangle2.verts.push_back(glm::vec3( -(nWidth2), (nHeight2), 1.0f));



	rectangle2.drawMode = GL_TRIANGLES;

	rectangle2.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle2.uvs.push_back(glm::vec2( tWidth2, 0.f));
	rectangle2.uvs.push_back(glm::vec2( tWidth2, tHeight2));
	rectangle2.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle2.uvs.push_back(glm::vec2( tWidth2, tHeight2));
	rectangle2.uvs.push_back(glm::vec2(0.0f, tHeight2));

	//Construct vao and vbos for the triangle
	RenderingEngine::assignBuffers(rectangle2);

	//Send the triangle data to the GPU
	//Must be done every time the triangle is modified in any way, ex. verts, colors, normals, uvs, etc.
	RenderingEngine::setBufferData(rectangle2);

	//Add the triangle to the scene objects
	objects.push_back(rectangle2); 

	//////////////////////////////////////////

	
}

void Scene::rotateImage() {
	glUseProgram(renderer->shaderProgram);
	std::cout << float(cos(rads)) << std::endl;
	std::cout << float(-sin(rads)) << std::endl;
	std::cout << float(sin(rads)) << std::endl;
	std::cout << float(cos(rads)) << std::endl;

	float rotationMatrix[9] {
		float(cos(rads)),	float(-sin(rads)),		0.0f,
		float(sin(rads)),	float(cos(rads)),		0.0f,
		0.0f,				0.0f,					1.0f
	};
	
	GLuint rotateUniform = glGetUniformLocation(renderer->shaderProgram, "rotateMatrix");
	glUniformMatrix3fv(rotateUniform, 1, GL_FALSE, rotationMatrix);
}
void Scene::setTextureName(const char* tName) {
	textureName = tName;
}

void Scene::setRadians(float f){
	rads = f;
}

float Scene::getRadians() {
	return rads;
}