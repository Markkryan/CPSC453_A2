/*
 * Scene.cpp
 *
 *  Created on: Sep 10, 2018
 *  Author: John Hall
 */

#include "Scene.h"

#include <iostream>

#include "RenderingEngine.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//**Must include glad and GLFW in this order or it breaks**
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "texture.h"


Scene::Scene(RenderingEngine* renderer) : renderer(renderer) {
	
	MyTexture texture;
	textureName = "image1-mandrill.png";
	bool flag = InitializeTexture(&texture, textureName, GL_TEXTURE_RECTANGLE);
	if (!flag) {
		std::cout << "Failed to initialize texture" << std::endl;
	}
	//Load texture uniform
	//Shaders need to be active to load uniforms
	glUseProgram(renderer->shaderProgram);
	//Set which texture unit the texture is bound to
	glActiveTexture(GL_TEXTURE0);
	//Bind the texture to GL_TEXTURE0
	glBindTexture(GL_TEXTURE_RECTANGLE, texture.textureID);
	//Get identifier for uniform
	GLuint uniformLocation = glGetUniformLocation(renderer->shaderProgram, "imageTexture");
	//Load texture unit number into uniform
	glUniform1i(uniformLocation, 0);

	

	if(renderer->CheckGLErrors()) {
		std::cout << "Texture creation failed" << std::endl;
	}

		// three vertex positions and assocated colours of a triangle
	rectangle.verts.push_back(glm::vec3( -1.0f, -1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( 1.0f,  -1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( 1.0f, 1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( -1.0f, -1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( 1.0f, 1.0f, 1.0f));
	rectangle.verts.push_back(glm::vec3( -1.0f, 1.0f, 1.0f));

	/*rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));*/



	rectangle.drawMode = GL_TRIANGLES;

	rectangle.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle.uvs.push_back(glm::vec2( float(texture.width), 0.f));
	rectangle.uvs.push_back(glm::vec2( float(texture.width), float(texture.height)));
	rectangle.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle.uvs.push_back(glm::vec2( float(texture.width), float(texture.height)));
	rectangle.uvs.push_back(glm::vec2(0.0f, float(texture.height)));

	//Construct vao and vbos for the triangle
	RenderingEngine::assignBuffers(rectangle);

	//Send the triangle data to the GPU
	//Must be done every time the triangle is modified in any way, ex. verts, colors, normals, uvs, etc.
	RenderingEngine::setBufferData(rectangle);

	//Add the triangle to the scene objects
	objects.push_back(rectangle);


}

Scene::~Scene() {

}

void Scene::displayScene() {
	renderer->RenderScene(objects);
}

void Scene::changeColorEffect(int color) {
	glUseProgram(renderer->shaderProgram);
	colorUniform = glGetUniformLocation(renderer->shaderProgram, "colorEffect");
	glUniform1i(colorUniform, color);
}

void Scene::changeSobelEffect(int sobel) {
	glUseProgram(renderer->shaderProgram);
	sobelUniform = glGetUniformLocation(renderer->shaderProgram, "sobel");
	glUniform1i(sobelUniform, sobel);
}

void Scene::changeGaussianEffect(int gaussian) {
	glUseProgram(renderer->shaderProgram);
	gaussianUniform = glGetUniformLocation(renderer->shaderProgram, "gaussian");
	glUniform1i(gaussianUniform, gaussian);
}

void Scene::changeImage(const char* fileName, bool effectsFlag) {
	objects.clear();
	rectangle.verts.clear();
	rectangle.uvs.clear();
	setTextureName(fileName);
	drawImage(fileName, effectsFlag);
}

void Scene::blendImages(const char* backgroundImageName){
	objects.clear();
	rectangle.verts.clear();
	rectangle.uvs.clear();
	glEnable(GL_BLEND);
	glBlendFunc(GL_ONE, GL_ZERO);
	drawImage(backgroundImageName, false);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//drawImage(textureName, true);
	
	
}

void Scene::drawImage(const char* name, bool flag) {
	MyTexture texture;
	
	InitializeTexture(&texture, name, GL_TEXTURE_RECTANGLE);
	glUseProgram(renderer->shaderProgram);
	
	//Set which texture unit the texture is bound to
	glActiveTexture(GL_TEXTURE0);
	//Bind the texture to GL_TEXTURE0
	glBindTexture(GL_TEXTURE_RECTANGLE, texture.textureID);
	//Get identifier for uniform
	GLuint uniformLocation = glGetUniformLocation(renderer->shaderProgram, "imageTexture");
	//Load texture unit number into uniform
	glUniform1i(uniformLocation, 0);
	if(renderer->CheckGLErrors()) {
		std::cout << "Texture creation failed" << std::endl;
	}

	effectsUniform = glGetUniformLocation(renderer->shaderProgram, "applyEffectsFlag");
	glUniform1i(effectsUniform, flag);

	float tHeight = texture.height;
	float tWidth = texture.width;
	float nHeight = 0.0f;
	float nWidth = 0.0f;

	if (tHeight >= tWidth) {
		nHeight = 1.0f;
		nWidth = tWidth / (tHeight);
	} else {
		nWidth = 1.0f;
		nHeight = tHeight / (tWidth);
	}
	// three vertex positions and assocated colours of a triangle
	rectangle.verts.push_back(glm::vec3( -(nWidth), -(nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( (nWidth),  -(nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( (nWidth), (nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( -(nWidth), -(nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( (nWidth), (nHeight), 1.0f));
	rectangle.verts.push_back(glm::vec3( -(nWidth), (nHeight), 1.0f));

	/*rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));
	rectangle.colors.push_back(glm::vec3( 1.0f, 0.0f, 0.0f));*/



	rectangle.drawMode = GL_TRIANGLES;

	rectangle.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle.uvs.push_back(glm::vec2( tWidth, 0.f));
	rectangle.uvs.push_back(glm::vec2( tWidth, tHeight));
	rectangle.uvs.push_back(glm::vec2( 0.0f, 0.0f));
	rectangle.uvs.push_back(glm::vec2( tWidth, tHeight));
	rectangle.uvs.push_back(glm::vec2(0.0f, tHeight));

	//Construct vao and vbos for the triangle
	RenderingEngine::assignBuffers(rectangle);

	//Send the triangle data to the GPU
	//Must be done every time the triangle is modified in any way, ex. verts, colors, normals, uvs, etc.
	RenderingEngine::setBufferData(rectangle);

	//Add the triangle to the scene objects
	objects.push_back(rectangle);
}

void Scene::setTextureName(const char* tName) {
	textureName = tName;
}