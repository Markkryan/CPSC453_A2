/*
 * main.cpp
 *
 *  Created on: Sep 10, 2018
 *      Author: John Hall
 */
#include "Program.h"

int main (int argc, char* argv[]) {
	Program p;
	p.start();
	return 0;
}



